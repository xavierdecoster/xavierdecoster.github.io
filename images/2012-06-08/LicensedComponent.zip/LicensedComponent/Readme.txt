This project is configured to auto-build the NuGet package and drop it into your local NuGet cache, ready for immediate consumption.
Simply configure this cache as a NuGet repository in Visual Studio (Tools > Library Package Manager > Package Manager Settings, PackageSources tab).
The local NuGet cache can be found here: %LocalAppData%\NuGet\Cache