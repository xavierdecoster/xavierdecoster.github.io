﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shared.Library
{
    public abstract class BaseClass
    {
        protected abstract void DoSomething();

        public void Execute()
        {
            Console.WriteLine("Base class did something");
            DoSomething();
        }
    }
}
