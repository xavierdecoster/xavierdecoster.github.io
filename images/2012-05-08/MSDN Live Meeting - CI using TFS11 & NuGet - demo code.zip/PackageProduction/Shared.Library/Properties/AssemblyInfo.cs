﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Shared.Library")]
[assembly: AssemblyDescription("This is a sample package containing a shared library.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Xavier Decoster")]
[assembly: AssemblyProduct("Shared.Library")]
[assembly: AssemblyCopyright("Copyright © Xavier Decoster 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("1e2778ab-bf1a-43e8-ac55-15b6047b9022")]
[assembly: AssemblyVersion("1.0.0.23")]
[assembly: AssemblyFileVersion("1.0.0508.03")]
