﻿using System;
using Shared.Another.Library;
using Shared.Library;
namespace ConsumingClient
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClassDoesSomething i = new MyClassDoesSomething();
            i.Execute();
            PrintSomething ps = new PrintSomething();
            ps.Useful();
            Console.ReadLine();
        }
    }

    public class MyClassDoesSomething : BaseClass
    {
        protected override void DoSomething()
        {
            Console.WriteLine("My class did something");
        }
    }
}
