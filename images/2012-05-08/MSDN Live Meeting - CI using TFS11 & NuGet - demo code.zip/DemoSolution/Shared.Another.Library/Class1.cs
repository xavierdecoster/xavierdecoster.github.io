﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shared.Another.Library
{
    public class PrintSomething
    {
        public void Useful()
        {
            Console.WriteLine("I printed something useful");
        }
    }
}
